#include "inode_manager.h"

// disk layer -----------------------------------------

disk::disk()
{
  bzero(blocks, sizeof(blocks));
}

void
disk::read_block(blockid_t id, char *buf)
{
	memcpy(buf, blocks[id], BLOCK_SIZE);
}

void
disk::write_block(blockid_t id, const char *buf)
{
	 memcpy(blocks[id], buf, BLOCK_SIZE);
}

// block layer -----------------------------------------

// Allocate a free disk block.
blockid_t
block_manager::alloc_block()
{
  /*
   * your code goes here.
   * note: you should mark the corresponding bit in block bitmap when alloc.
   * you need to think about which block you can start to be allocated.
   */
	//可以使用的block从当前加一，也就是IBLOCK+1开始
  for(int i = (IBLOCK(INODE_NUM, sb.nblocks)+1); i < BLOCK_NUM; i++){
    if(!using_blocks[i]){
      using_blocks[i] = true;
      return i;
    }
}
  return 0;
}

void
block_manager::free_block(uint32_t id)
{
  /* 
   * your code goes here.
   * note: you should unmark the corresponding bit in the block bitmap when free.
   */
  using_blocks[id] = false;
  return;
}

// The layout of disk should be like this:
// |<-sb->|<-free block bitmap->|<-inode table->|<-data->|
block_manager::block_manager()
{
  d = new disk();

  // format the disk
  sb.size = BLOCK_SIZE * BLOCK_NUM;
  sb.nblocks = BLOCK_NUM;
  sb.ninodes = INODE_NUM;

}

void
block_manager::read_block(uint32_t id, char *buf)
{
  d->read_block(id, buf);
}

void
block_manager::write_block(uint32_t id, const char *buf)
{
  d->write_block(id, buf);
}

// inode layer -----------------------------------------

inode_manager::inode_manager()
{
  bm = new block_manager();
  uint32_t root_dir = alloc_inode(extent_protocol::T_DIR);
  if (root_dir != 1) {
    printf("\tim: error! alloc first inode %d, should be 1\n", root_dir);
    exit(0);
  }
}

/* Create a new file.
 * Return its inum. */
uint32_t
inode_manager::alloc_inode(uint32_t type)
{
  /* 
   * your code goes here.
   * note: the normal inode block should begin from the 2nd inode block.
   * the 1st is used for root_dir, see inode_manager::inode_manager().
   */
  int number=1;
  while(get_inode(number)){
  	number++;                  //这里如果死循环怎么办？
  }
  struct inode *ino =(inode_t *)malloc(sizeof(inode_t));
  ino->type = type;
  ino->atime = (unsigned int)time(NULL);
  ino->mtime = (unsigned int)time(NULL);
  ino->ctime = (unsigned int)time(NULL);
  put_inode(number, ino);
  free(ino);
  return number;
}

void
inode_manager::free_inode(uint32_t inum)
{
  /* 
   * your code goes here.
   * note: you need to check if the inode is already a freed one;
   * if not, clear it, and remember to write back to disk.
   */
  inode_t *ino = get_inode(inum);
  if(ino){
    ino->type = 0;                         //有没有一种办法可以不经过转换，直接修改type为0？
    
    put_inode(inum, ino);
    free(ino);
  }
  return;
}


/* Return an inode structure by inum, NULL otherwise.
 * Caller should release the memory. */
struct inode* 
inode_manager::get_inode(uint32_t inum)
{
  struct inode *ino;
  /* 
   * your code goes here.
   */
  struct inode *ino_disk;
  char buf[BLOCK_SIZE];
  if (inum < 0 || inum >= INODE_NUM) {
    //情况一：范围不在合适范围内
    return NULL;
  }
  //IBLOCK这一堆是用来计算blockid
  //
  bm->read_block(IBLOCK(inum, bm->sb.nblocks), buf);


  ino_disk = (struct inode*)buf ;
  if (ino_disk->type == 0) {
    return NULL;
  }

  ino = (struct inode*)malloc(sizeof(struct inode));
  *ino = *ino_disk;
  return ino;
}

void
inode_manager::put_inode(uint32_t inum, struct inode *ino)
{
  char buf[BLOCK_SIZE];
  struct inode *ino_disk;

  //printf("\tim: put_inode %d\n", inum);
  if (ino == NULL)
    return;

  bm->read_block(IBLOCK(inum, bm->sb.nblocks), buf);
  ino_disk = (struct inode*)buf + inum%IPB;
  *ino_disk = *ino;
  bm->write_block(IBLOCK(inum, bm->sb.nblocks), buf);
}


















//下面这两个函数是新增的
blockid_t
inode_manager::convert_n_to_blockid(inode_t *ino, uint32_t n)
{
  char buf[BLOCK_SIZE];
  blockid_t res;

  assert(ino);
  if(n < NDIRECT)
    res = ino->blocks[n];
  else if(n < MAXFILE){
    if(ino->blocks[NDIRECT])
    {bm->read_block(ino->blocks[NDIRECT], buf);      
    
    res = ((blockid_t *)buf)[n - NDIRECT];
    }
  }else{
    
    return 0;                                            //找不到对应的blockid，那就返回0，标志着失败
  }

  return res;
}

void 
inode_manager::alloc_nth_block(inode_t *ino, uint32_t n)
{
  char buf[BLOCK_SIZE];

  if(n < NDIRECT)
    ino->blocks[n] = bm->alloc_block();
  else if(n < MAXFILE){
    if(!ino->blocks[NDIRECT]){
     
      ino->blocks[NDIRECT] = bm->alloc_block();                //没有二级目录的话就要新建一个
    }
    bm->read_block(ino->blocks[NDIRECT], buf);      
    ((blockid_t *)buf)[n - NDIRECT] = bm->alloc_block();
    bm->write_block(ino->blocks[NDIRECT], buf); 
  }else{
    exit(0);                                                   //满了导致没有空间了
  }
}































#define MIN(a,b) ((a)<(b) ? (a) : (b))

/* Get all the data of a file by inum. 
 * Return alloced data, should be freed by caller. */
void
inode_manager::read_file(uint32_t inum, char **buf_out, int *size)
{
  /*
   * your code goes here.
   * note: read blocks related to inode number inum,
   * and copy them to buf_out
   */
  int block_num = 0;
  int remain_size = 0;
  char buf[BLOCK_SIZE];
  int i = 0;

  inode_t *ino = get_inode(inum);
  if(ino){
    *size = ino->size;                           //这里得到size的就是inode对应得文件有多少byte
    
    *buf_out = (char *)malloc(*size);

    block_num = *size / BLOCK_SIZE;             //需要读得文件有多少个完整的block
    remain_size = *size % BLOCK_SIZE;           //还余下多少单个的byte

    for(; i < block_num; i++){
      bm->read_block(convert_n_to_blockid(ino, i), buf);
      memcpy(*buf_out + i*BLOCK_SIZE, buf, BLOCK_SIZE);
    }
    if(remain_size){
      bm->read_block(convert_n_to_blockid(ino, i), buf);
      memcpy(*buf_out + i*BLOCK_SIZE, buf, remain_size);
    }
    free(ino);
  }
  return;
}

/* alloc/free blocks if needed */
void
inode_manager::write_file(uint32_t inum, const char *buf, int size)
{
  /*
   * your code goes here.
   * note: write buf to blocks of inode inum.
   * you need to consider the situation when the size of buf 
   * is larger or smaller than the size of original inode
   */
    int block_num = 0;
  int remain_size = 0;
  int old_blocks, new_blocks;
  char temp[BLOCK_SIZE];
  int i = 0;

  assert(size >= 0 && (uint32_t)size <= MAXFILE * BLOCK_SIZE);            //判断size是否过大导致

  inode_t *ino = get_inode(inum);
  if(ino){
    assert((unsigned int)size <= MAXFILE * BLOCK_SIZE);
    assert(ino->size <= MAXFILE * BLOCK_SIZE);

    old_blocks = ino->size == 0? 0 : (ino->size - 1)/BLOCK_SIZE + 1;     //inode本身有多少block
    new_blocks = size == 0? 0 : (size - 1)/BLOCK_SIZE + 1;               //新建的需要多少block



    if(old_blocks < new_blocks)                                          //如果不够大，就只能新申请空间
      for(int j = old_blocks; j < new_blocks; j++)
        alloc_nth_block(ino, j);
    else if(old_blocks > new_blocks)                                     //如果大多了，就要free过多的block
      for(int j = new_blocks; j < old_blocks; j++)
        bm->free_block(convert_n_to_blockid(ino, j));

    block_num = size / BLOCK_SIZE;
    remain_size = size % BLOCK_SIZE;

    for(; i < block_num; i++)
      bm->write_block(convert_n_to_blockid(ino, i), buf + i*BLOCK_SIZE);
    if(remain_size){
      memcpy(temp, buf + i*BLOCK_SIZE, remain_size);
      bm->write_block(convert_n_to_blockid(ino, i), temp);
    }

    ino->size = size;
    ino->atime = (unsigned int)time(NULL);
    ino->mtime = (unsigned int)time(NULL);
    ino->ctime = (unsigned int)time(NULL);
    put_inode(inum, ino);
    free(ino);
  }
  return;
}

void
inode_manager::get_attr(uint32_t inum, extent_protocol::attr &a)
{
  /*
   * your code goes here.
   * note: get the attributes of inode inum.
   * you can refer to "struct attr" in extent_protocol.h
   */
   //这里a和ino没有差别，只是用来输出
  struct inode *ino = get_inode(inum);
  if(!ino){ return;}
  else{
  a.type = ino->type;
  a.atime = ino->atime;
  a.mtime = ino->mtime;
  a.ctime = ino->ctime;
  a.size = ino->size;
  free(ino);
  return;
  }
}

void
inode_manager::remove_file(uint32_t inum)
{
  /*
   * your code goes here
   * note: you need to consider about both the data block and inode of the file
   */
  

  inode_t *ino = get_inode(inum);

  int block_num = ino->size == 0? 0 : (ino->size - 1)/BLOCK_SIZE + 1;
  for(int i = 0; i < block_num; i++)
    bm->free_block(convert_n_to_blockid(ino, i));
  if(block_num > NDIRECT)
    bm->free_block(ino->blocks[NDIRECT]);
  bzero(ino, sizeof(inode_t));

  free_inode(inum);
  free(ino);
  return;
}
